<?php
    $connect = mysqli_connect("localhost", "root", "", "straf");
    if (!$connect) die("Error");
    